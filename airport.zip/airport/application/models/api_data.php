<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_data extends CI_Model{

    public function __construct() {
        parent::__construct();
        
        
    }
    
    public function search_airport($data){
            $airport_query = $this->db->get_where('airports',array('airport_code'=>$data['code']));
        
        if($airport_query->num_rows() > 0){
            $airport_query = $airport_query->result();
            
            return $airport_query;
            
        }else{
            return "No Airport Found";
        }
        
    }
    
}
