<!DOCTYPE html>
<html lang="en">
<body>

<div id="container">
	<div class="login-panel panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Search Airport</h3>
            </div>
            <div class="panel-body">
                <p>The API URL will be like: http://localhost/airport/index.php/api/search/100</p>
                <p>Airport Codes: 100, 200, 300, 400</p>
            </div>
        </div>
</div>

</body>
</html>